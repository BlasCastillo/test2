<?php $__env->startSection('plantillapadre'); ?>
<body class="antialiased">
        <div class="relative flex items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center py-4 sm:pt-0">
            <?php if(Route::has('login')): ?>
                <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                    <?php if(auth()->guard()->check()): ?>
                        <a class="btn btn-primary" href="<?php echo e(url('/home')); ?>" class="text-sm text-gray-700 dark:text-gray-500 underline">Home</a>
                    <?php else: ?>
                        <a class="btn btn-primary" href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 dark:text-gray-500 underline">Log in</a>

                        <?php if(Route::has('register')): ?>
                            <a class="btn btn-primary" href="<?php echo e(route('register')); ?>" class="ml-4 text-sm text-gray-700 dark:text-gray-500 underline">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <style>

                .centrar{
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100%;
}
.display-1{
    color: white;
}

            </style>
            
            <div class="centrar" >
            <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel"  >
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  
  <div class="carousel-inner">
    <div class="carousel-item active">
    <div class="card" style="width: 18rem;">
  <img src="https://cryptoinversiones.co/images/discover.svg" class="d-block w-100" alt="...">
  <div class="card-body">
    <h5 class="card-title">Plan Bronce</h5>
    <p class="card-text">Invierte 10 USDT y gana 30 en 10 días</p>
    <a href="#" class="btn btn-primary">Contratar</a>
  </div>
</div>
    </div>
    <div class="carousel-item">
    <div class="card" style="width: 18rem;">
  <img src="https://static.wixstatic.com/media/3b0a4e_cca497a17f8d42429cfdd2c140104c0e~mv2.png/v1/fit/w_2500,h_1330,al_c/3b0a4e_cca497a17f8d42429cfdd2c140104c0e~mv2.png" class="d-block w-100" alt="...">
  <div class="card-body">
    <h5 class="card-title">Plan Plata</h5>
    <p class="card-text">SInvierte 30 USDT y gana 100 en 10 días.</p>
    <a href="#" class="btn btn-primary">Go somewhere</a>
  </div>
</div>
    </div>
    <div class="carousel-item">
    <div class="card" style="width: 18rem;">
  <img src="https://cryptoinversionesonline.com/wp-content/uploads/2020/01/1-Logo-Sin-Vectores.jpg" class="d-block w-100" alt="...">
  <div class="card-body">
    <h5 class="card-title">Plan Oro</h5>
    <p class="card-text">Invierte 100 USDT y gana 350 en 10 Días</p>
    <a href="#" class="btn btn-primary">Go somewhere</a>
  </div>
</div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</div>
<center><h1 class="display-1">Nuestro Respaldo</h1></center>
<br>
<div class="centrar" >
<iframe width="560" height="315"  src="https://www.youtube.com/embed/BeJO3kci3fY?start=30" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; mute(); clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>
<div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active" data-bs-interval="10000">
      <img src="..." class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>First slide label</h5>
        <p>Some representative placeholder content for the first slide.</p>
      </div>
    </div>
    <div class="carousel-item" data-bs-interval="2000">
      <img src="..." class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>Second slide label</h5>
        <p>Some representative placeholder content for the second slide.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="https://s3.sa-east-1.amazonaws.com/www.satoshitango.com/blog/wp-content/uploads/2020/06/03120458/Ganar-bitcoins.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>Third slide label</h5>
        <p>Some representative placeholder content for the third slide.</p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

<?php $__env->stopSection(); ?>



    

    
<?php echo $__env->make('layouts.plantillapadre', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\starminer\resources\views/welcome.blade.php ENDPATH**/ ?>