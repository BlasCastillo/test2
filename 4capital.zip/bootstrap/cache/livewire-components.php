<?php return array (
  'chatform' => 'App\\Http\\Livewire\\Chatform',
  'chatlist' => 'App\\Http\\Livewire\\Chatlist',
);